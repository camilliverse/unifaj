/* ======================================================================
   ALOCAÇÃO DAS CLASSES (uso do "new") COM VALORES FIXOS DE EXEMPLO
   ====================================================================== */

// 1) Plano de saúde principal
let plano1 = new PlanoDeSaude("Plano Vida Plena", "Operadora Saúde Total");

// 2) Hospital
let hospital1 = new Hospital("Hospital São Lucas", "Av. Central, 1000", 120);

// 3) Clínica
let clinica1 = new Clinica("Clínica Bem Estar", "Rua das Flores, 55", ["Cardiologia", "Ortopedia"]);

// 4) Laboratório
let laboratorio1 = new Laboratorio("Lab Diagnóstica", "Rua dos Testes, 20", true);

// 5) Médico (exemplo fixo, além do que será cadastrado via formulário)
let medico1 = new Medico("Carlos Andrade", "111.222.333-44", "1980-05-10", "CRM-12345", "Cardiologia");

// 6) Fisioterapeuta
let fisio1 = new Fisioterapeuta("Beatriz Lima", "222.333.444-55", "1990-02-15", "CREFITO-9876", "Ortopédica");

// 7) Paciente (exemplo fixo, além do que será cadastrado via formulário)
let paciente1 = new Paciente("Mariana Souza", "333.444.555-66", "1995-08-20", "PL-000123");

// 8) Consulta
let consulta1 = new Consulta(paciente1, medico1, "20/09/2026 14:00", "Clínica Bem Estar");

// 9) Exame (via método do médico, que também usa "new Exame" internamente)
let exame1 = medico1.solicitarExame(paciente1, "Eletrocardiograma", laboratorio1);

// 10) Consulta de Retorno
let retorno1 = new ConsultaRetorno(paciente1, medico1, "05/10/2026 10:00", "Clínica Bem Estar", consulta1);

// 11) Internação
let internacao1 = new Internacao(paciente1, hospital1, "Observação cardíaca", "21/09/2026");

// Registrando tudo dentro do plano de saúde
plano1.cadastrarHospital(hospital1);
plano1.cadastrarClinica(clinica1);
plano1.cadastrarLaboratorio(laboratorio1);
plano1.cadastrarMedico(medico1);
plano1.cadastrarFisioterapeuta(fisio1);
plano1.cadastrarPaciente(paciente1);

/* ======================================================================
   FUNÇÕES DE APOIO PARA EXIBIR RESULTADOS NA TELA
   ====================================================================== */

function log(mensagem) {
  const saida = document.getElementById("saida");
  const linha = document.createElement("p");
  linha.textContent = mensagem;
  saida.appendChild(linha);
}

function limparSaida() {
  document.getElementById("saida").innerHTML = "";
}

/* ======================================================================
   BOTÃO 1: Demonstrar a alocação (new) de todas as classes fixas
   ====================================================================== */
function demonstrarAlocacaoFixa() {
  limparSaida();
  log("== OBJETOS CRIADOS COM 'new' E VALORES FIXOS ==");
  log(plano1.toString());
  log(hospital1.toString());
  log(clinica1.toString());
  log(laboratorio1.toString());
  log(medico1.toString());
  log(fisio1.toString());
  log(paciente1.toString());
  log(consulta1.toString());
  log(exame1.toString());
  log(retorno1.toString());
  log(internacao1.toString());

  // Demonstrando métodos de comportamento entre objetos
  log("---- Ações entre objetos ----");
  log(medico1.atenderConsulta(consulta1));
  log(laboratorio1.realizarExame(exame1));
  log(exame1.toString());
  log(medico1.reavaliarPaciente(retorno1, "Paciente estável, exames normais."));
  log(retorno1.toString());
  log(hospital1.internarPaciente(internacao1));
  log(internacao1.darAlta("25/09/2026"));
  log(fisio1.realizarSessao(paciente1, "Fortalecimento muscular"));
}

/* ======================================================================
   BOTÃO 2 e 3: Cadastro de Paciente e Médico usando valores de INPUT
   (as duas classes escolhidas para receber dados do formulário HTML)
   ====================================================================== */

function cadastrarPacienteViaFormulario() {
  const nome = document.getElementById("pacienteNome").value;
  const cpf = document.getElementById("pacienteCpf").value;
  const nascimento = document.getElementById("pacienteNascimento").value;
  const carteirinha = document.getElementById("pacienteCarteirinha").value;

  if (!nome || !cpf || !nascimento || !carteirinha) {
    alert("Preencha todos os campos do Paciente antes de cadastrar.");
    return;
  }

  const novoPaciente = new Paciente(nome, cpf, nascimento, carteirinha);
  plano1.cadastrarPaciente(novoPaciente);

  log("== NOVO PACIENTE CADASTRADO VIA FORMULÁRIO ==");
  log(novoPaciente.toString());
}

function cadastrarMedicoViaFormulario() {
  const nome = document.getElementById("medicoNome").value;
  const cpf = document.getElementById("medicoCpf").value;
  const crm = document.getElementById("medicoCrm").value;
  const especialidade = document.getElementById("medicoEspecialidade").value;

  if (!nome || !cpf || !crm || !especialidade) {
    alert("Preencha todos os campos do Médico antes de cadastrar.");
    return;
  }

  const novoMedico = new Medico(nome, cpf, "não informado", crm, especialidade);
  plano1.cadastrarMedico(novoMedico);

  log("== NOVO MÉDICO CADASTRADO VIA FORMULÁRIO ==");
  log(novoMedico.toString());
}

function mostrarResumoPlano() {
  log("== RESUMO ATUAL DO PLANO DE SAÚDE ==");
  log(plano1.toString());
  log(`Total de pacientes cadastrados: ${plano1.pacientes.length}`);
  log(`Total de médicos credenciados: ${plano1.medicos.length}`);
}
