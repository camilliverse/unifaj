/* ======================================================================
   AULA 2 - EXERCÍCIO 3 - JAVASCRIPT ORIENTADO A OBJETOS
   TEMA: PLANO DE SAÚDE
   ====================================================================== */

/* ---------------------- 1) Classe base: Pessoa ---------------------- */
class Pessoa {
  constructor(nome, cpf, dataNascimento) {
    this.nome = nome;
    this.cpf = cpf;
    this.dataNascimento = dataNascimento;
  }

  toString() {
    return `${this.nome} (CPF: ${this.cpf})`;
  }
}

/* ---------------------- 2) Classe Paciente --------------------------- */
class Paciente extends Pessoa {
  constructor(nome, cpf, dataNascimento, numeroCarteirinha) {
    super(nome, cpf, dataNascimento);
    this.numeroCarteirinha = numeroCarteirinha;
    this.consultas = [];
    this.exames = [];
    this.internacoes = [];
  }

  marcarConsulta(consulta) {
    this.consultas.push(consulta);
    return `Consulta marcada para ${this.nome} em ${consulta.dataHora}`;
  }

  adicionarExame(exame) {
    this.exames.push(exame);
  }

  registrarInternacao(internacao) {
    this.internacoes.push(internacao);
  }

  toString() {
    return `Paciente: ${this.nome} | Carteirinha: ${this.numeroCarteirinha}`;
  }
}

/* ---------------------- 3) Classe Medico ------------------------------ */
class Medico extends Pessoa {
  constructor(nome, cpf, dataNascimento, crm, especialidade) {
    super(nome, cpf, dataNascimento);
    this.crm = crm;
    this.especialidade = especialidade;
    this.agenda = [];
  }

  atenderConsulta(consulta) {
    this.agenda.push(consulta);
    return `Dr(a). ${this.nome} atendeu ${consulta.paciente.nome}`;
  }

  // Médico solicita exame para um paciente em um laboratório credenciado
  solicitarExame(paciente, tipoExame, laboratorio) {
    const exame = new Exame(tipoExame, paciente, this, laboratorio);
    paciente.adicionarExame(exame);
    return exame;
  }

  // Em consulta de retorno, o médico reavalia paciente e exames
  reavaliarPaciente(consultaRetorno, observacoes) {
    consultaRetorno.reavaliar(observacoes);
    return `Reavaliação concluída para ${consultaRetorno.paciente.nome}: ${observacoes}`;
  }

  toString() {
    return `Dr(a). ${this.nome} - CRM ${this.crm} (${this.especialidade})`;
  }
}

/* ---------------------- 4) Classe Fisioterapeuta ---------------------- */
class Fisioterapeuta extends Pessoa {
  constructor(nome, cpf, dataNascimento, registroCrefito, especialidade) {
    super(nome, cpf, dataNascimento);
    this.registroCrefito = registroCrefito;
    this.especialidade = especialidade;
    this.sessoes = [];
  }

  realizarSessao(paciente, procedimento) {
    const sessao = { paciente: paciente.nome, procedimento, data: new Date().toLocaleDateString() };
    this.sessoes.push(sessao);
    return `Sessão de ${procedimento} realizada em ${paciente.nome}`;
  }

  toString() {
    return `Fisioterapeuta ${this.nome} - CREFITO ${this.registroCrefito}`;
  }
}

/* ---------------------- 5) Classe Hospital ----------------------------- */
class Hospital {
  constructor(nome, endereco, numeroLeitos) {
    this.nome = nome;
    this.endereco = endereco;
    this.numeroLeitos = numeroLeitos;
    this.internacoes = [];
  }

  internarPaciente(internacao) {
    this.internacoes.push(internacao);
    return `${internacao.paciente.nome} internado(a) no ${this.nome}`;
  }

  toString() {
    return `Hospital ${this.nome} (${this.numeroLeitos} leitos)`;
  }
}

/* ---------------------- 6) Classe Clinica ------------------------------ */
class Clinica {
  constructor(nome, endereco, especialidades) {
    this.nome = nome;
    this.endereco = endereco;
    this.especialidades = especialidades; // array de strings
    this.consultasAgendadas = [];
  }

  agendarConsulta(consulta) {
    this.consultasAgendadas.push(consulta);
    return `Consulta agendada na clínica ${this.nome}`;
  }

  toString() {
    return `Clínica ${this.nome} - Especialidades: ${this.especialidades.join(", ")}`;
  }
}

/* ---------------------- 7) Classe Laboratorio --------------------------- */
class Laboratorio {
  constructor(nome, endereco, credenciado) {
    this.nome = nome;
    this.endereco = endereco;
    this.credenciado = credenciado; // boolean
  }

  realizarExame(exame) {
    exame.realizado = true;
    exame.resultado = "Resultado dentro dos parâmetros de normalidade";
    return `Exame de ${exame.tipo} realizado no laboratório ${this.nome}`;
  }

  toString() {
    return `Laboratório ${this.nome} - ${this.credenciado ? "Credenciado" : "Não credenciado"}`;
  }
}

/* ---------------------- 8) Classe Consulta ------------------------------- */
class Consulta {
  constructor(paciente, medico, dataHora, local) {
    this.paciente = paciente;
    this.medico = medico;
    this.dataHora = dataHora;
    this.local = local;
  }

  toString() {
    return `Consulta: ${this.paciente.nome} com Dr(a). ${this.medico.nome} em ${this.dataHora} (${this.local})`;
  }
}

/* ---------------------- 9) Classe ConsultaRetorno (herda Consulta) ------- */
class ConsultaRetorno extends Consulta {
  constructor(paciente, medico, dataHora, local, consultaOriginal) {
    super(paciente, medico, dataHora, local);
    this.consultaOriginal = consultaOriginal;
    this.observacoes = "";
  }

  reavaliar(observacoes) {
    this.observacoes = observacoes;
  }

  toString() {
    return `Retorno: ${this.paciente.nome} com Dr(a). ${this.medico.nome} - Obs: ${this.observacoes || "(sem reavaliação ainda)"}`;
  }
}

/* ---------------------- 10) Classe Exame ---------------------------------- */
class Exame {
  constructor(tipo, paciente, medicoSolicitante, laboratorio) {
    this.tipo = tipo;
    this.paciente = paciente;
    this.medicoSolicitante = medicoSolicitante;
    this.laboratorio = laboratorio;
    this.realizado = false;
    this.resultado = null;
  }

  toString() {
    return `Exame de ${this.tipo} para ${this.paciente.nome}, solicitado por Dr(a). ${this.medicoSolicitante.nome} - ${this.realizado ? "Realizado" : "Pendente"}`;
  }
}

/* ---------------------- 11) Classe Internacao ------------------------------ */
class Internacao {
  constructor(paciente, hospital, motivo, dataEntrada) {
    this.paciente = paciente;
    this.hospital = hospital;
    this.motivo = motivo;
    this.dataEntrada = dataEntrada;
    this.dataSaida = null;
  }

  darAlta(dataSaida) {
    this.dataSaida = dataSaida;
    return `${this.paciente.nome} recebeu alta em ${dataSaida}`;
  }

  toString() {
    return `Internação: ${this.paciente.nome} no ${this.hospital.nome} - Motivo: ${this.motivo}`;
  }
}

/* ---------------------- 12) Classe PlanoDeSaude (classe "orquestradora") --- */
class PlanoDeSaude {
  constructor(nome, operadora) {
    this.nome = nome;
    this.operadora = operadora;
    this.pacientes = [];
    this.medicos = [];
    this.fisioterapeutas = [];
    this.hospitais = [];
    this.clinicas = [];
    this.laboratorios = [];
  }

  cadastrarPaciente(paciente) {
    this.pacientes.push(paciente);
    return `Paciente ${paciente.nome} cadastrado no plano ${this.nome}`;
  }

  cadastrarMedico(medico) {
    this.medicos.push(medico);
    return `Médico ${medico.nome} credenciado no plano ${this.nome}`;
  }

  cadastrarFisioterapeuta(fisio) {
    this.fisioterapeutas.push(fisio);
  }

  cadastrarHospital(hospital) {
    this.hospitais.push(hospital);
  }

  cadastrarClinica(clinica) {
    this.clinicas.push(clinica);
  }

  cadastrarLaboratorio(laboratorio) {
    this.laboratorios.push(laboratorio);
  }

  toString() {
    return `Plano de Saúde "${this.nome}" - Operadora: ${this.operadora} | Pacientes: ${this.pacientes.length} | Médicos: ${this.medicos.length}`;
  }
}
