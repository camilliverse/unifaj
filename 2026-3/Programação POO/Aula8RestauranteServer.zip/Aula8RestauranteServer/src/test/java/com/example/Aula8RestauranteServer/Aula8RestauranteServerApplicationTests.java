package com.example.Aula8RestauranteServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula8RestauranteServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
